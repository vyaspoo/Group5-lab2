<?php

$con=new mysqli("localhost", "root" ,"" ,"country");

if($con->connect_error)
{
    echo $con->connect_error;
    exit;
}
$result=$con->query("select * from city");
?>
<table border="1" align="center" cellpadding="10" cellspacing="0">
    <tr>
        <td>id</td>
        <td>City name</td>
        <td>Description</td>
        <td>Country</td>
                
    </tr>
    <?php
    while($row=$result->fetch_object())
    
    {
    ?>
 <tr>
    <td><?php echo $row->City_id; ?></td>
    <td><?php echo $row->City_name; ?></td>
    <td><?php echo $row->Description; ?></td>
    <td><?php echo $row->City1_id; ?></td>
       
    <td><a href="deletelab2c.php?did=<?php echo $row->City_id;?>">delete</a></td>
    
    <td><a href="edit.php?eid=<?php echo $row->City_id;?>">edit</a></td>
</tr>
<?php
    }
    ?>
</table>