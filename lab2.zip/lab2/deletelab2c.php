<?php
$con=new mysqli("localhost", "root","","country");

if($con->connect_error)
{
    echo $con->connect_error;
    exit;
}

$id=$_REQUEST["did"];

$exe=$con->query("delete from city where City_id='$id' ");

if($exe)
{
    header('location:lab2c.php');
}
 else
 {
     echo"something went wrong";
 }
?>