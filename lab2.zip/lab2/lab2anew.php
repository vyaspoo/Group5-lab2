<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "country";





// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO country (C_name,Acronym)
VALUES ('Europe','Eur')";

$sql = "INSERT INTO city (City_name,Description,City1_id)
VALUES ('Salvador','Beautiful',6)";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
?><br>
<br>
<?php 
$sql2 = "SELECT C_id,C_name,Acronym FROM country where C_name='Canada' ";
$result = $conn->query($sql2);

if ($result->num_rows > 0) {
    echo "<table border=1><tr><th>ID</th><th>Name</th><th>Acronym</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
echo "<tr>
        <th scope='row'>".$row['C_id']."</th>
        <td><a href='lab2bnew.php?country=".$row['Acronym']."'>
        ".$row['C_name']."</a></td>
        <td>".$row['Acronym']."</td>
        </tr>";
    }
    


      /*  echo "<tr><td>" . $row["C_id"]. "</td><td>" . $row["C_name"]. "</td><td>" . $row["Acronym"]. "</td></tr>";
        
         echo  "<a href='".$row["lab2bnew.php"]."'>".$row['C_name']."</a>";
         

    }*/
    echo "</table>";
} else {
    echo "0 results";
}
?>
<br>
<?php
$sql3 = "SELECT * FROM city";
$result = $conn->query($sql3);

if ($result->num_rows > 0) {
    echo "<table border=1><tr><th>ID</th><th>Name</th><th>Description</th><th>C_id</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["City_id"]. "</td><td>" . $row["City_name"]. "</td><td>" . $row["Description"]. "</td><td>" . $row["City1_id"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

?>
<br>
<br>
<?php



$sql4 = "SELECT C_id,C_name FROM country where C_name='india' ";
$result = $conn->query($sql4);

if ($result->num_rows > 0) {
    echo "<table border=1><tr><th>ID</th><th>Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["C_id"]. "</td><td>" . $row["C_name"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}


$conn->close();
?>