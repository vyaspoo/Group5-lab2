-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 03:56 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `country`
--

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `City_id` bigint(10) NOT NULL,
  `City_name` varchar(20) NOT NULL,
  `Description` varchar(20) NOT NULL,
  `City1_id` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`City_id`, `City_name`, `Description`, `City1_id`) VALUES
(1, 'Brampton', 'GTA', 3),
(2, 'Toronto', 'GTA', 3),
(3, 'Ahmedabad', 'Metropolitan', 4),
(4, 'London', 'Metropolitan', 5),
(5, 'Paris', 'Lovable', 9),
(6, 'Auckland', 'Great', 8),
(7, 'Salvador', 'Beautiful', 6);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `C_id` int(2) NOT NULL,
  `C_name` varchar(20) NOT NULL,
  `Acronym` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`C_id`, `C_name`, `Acronym`) VALUES
(3, 'Canada', 'CA'),
(4, 'India', 'IN'),
(5, 'United Kingdom', 'UK'),
(6, 'Brazil', 'BR'),
(7, 'Canada', ''),
(8, 'Newzealand', 'NZ'),
(9, 'Europe', 'Eur'),
(10, 'Europe', 'Eur'),
(11, 'Europe', 'Eur'),
(12, 'Europe', 'Eur'),
(13, 'Europe', 'Eur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`City_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`C_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `City_id` bigint(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `C_id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
