<?php

$con=new mysqli("localhost","root","","country");

if($con->connect_error)
{
    echo $con->connect_error;
    exit;
}
print_r($_REQUEST);
$id=$_REQUEST["eid"];

$result=$con->query("select * from city where City_id='$id'");

$row=$result->fetch_object();


$City_id=$row->City_id;

$City_name=$row->City_name;
$Description=$row->Description;
$City1_id=$row->City1_id;
//$e=$row->education;


if(isset($_REQUEST["submit"]))
{
    $City_id=$_REQUEST["City_id"];
    $City_name=$_REQUEST["City_name"];
    $Description=$_REQUEST["Description"];
    $City1_id=$_REQUEST["City1_id"];    
   
    
    $exe=$con->query("update city set City_id='$City_id',City_name='$City_name',Description='$Description',City1_id='$City1_id' where City_id='$id'");
    
    if($exe)
    {
        header('location:lab2c.php');
    }
    else
    {
        echo $exec->error_reporting;
    }
}
?>

<html>
    <head>
        <title>Hello</title>
    </head>
    <body>
        <form method="post">
        <table border="2" align="center" cellspacing="0" cellpadding="1">
            <tr>
                <td>Cityid:</td>
                <td> <input type="text" id="City_id" name="City_id" value="<?php echo $row->City_id;?>"></td>
            </tr>
            <tr>
                <td>Name:</td>
                <td><input type="text" id="City_name" name="City_name" value="<?php echo $row->City_name;?>"></td>
            </tr>
            <tr>
                 <td>Description:</td>
                 <td>
                     <input type="text" id="Description" name="Description" value="<?php echo $row->Description;?>">
                 </td>
            </tr>
            <tr>
                <td>Country id:</td>
                <td> <input type="text" id="City1_id" name="City1_id" value="<?php echo $row->City1_id;?>"></td>
                
            </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="submit" id="submit" value="update">
                    </td>
                </tr>
        </table>
    </form>
    </body>
</html>
