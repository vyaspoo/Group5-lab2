<?php

$con=new mysqli("localhost","root","","country");
        
        if($con->connect_error)
        {
            echo $con->connect_error;
            exit;
        }
        

        if(isset($_REQUEST["submit"]))
        {
            $name=$_REQUEST["name"];
           
            
            $exe=$con->query("insert into query(C_name)values('$name')");
            
            if($exe)
            {
                echo "Data inserted successfully";
            }
            else
            {
                echo"Somthing went wrong";
            }
        }
?>


<html>
    <head>
        <title>
            Database example
        </title>
    </head>
    <body>
        
        <form method="post">
            <table border="1" align="center" cellpadding="10" cellspacing="0">
                <tr>
                    <td>
                        Name:
                    </td>
                    <td>
                        <input type="text" id="name" name="name">
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" id="submit" name="submit" value="submit">
                    </td>
                </tr>

            </table>
        </form>